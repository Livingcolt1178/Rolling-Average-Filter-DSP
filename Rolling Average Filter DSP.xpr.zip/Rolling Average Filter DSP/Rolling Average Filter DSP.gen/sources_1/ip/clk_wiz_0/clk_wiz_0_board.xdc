#--------------------Physical Constraints-----------------


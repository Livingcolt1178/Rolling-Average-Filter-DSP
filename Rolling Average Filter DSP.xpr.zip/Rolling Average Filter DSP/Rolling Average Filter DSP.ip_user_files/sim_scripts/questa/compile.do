vlib questa_lib/work
vlib questa_lib/msim

vlib questa_lib/msim/xpm
vlib questa_lib/msim/xil_defaultlib

vmap xpm questa_lib/msim/xpm
vmap xil_defaultlib questa_lib/msim/xil_defaultlib

vlog -work xpm  -incr -mfcu  -sv "+incdir+../../../../../../AMDDesignTools/2025.2/Vivado/data/rsb/busdef" "+incdir+../../../Rolling Average Filter DSP.gen/sources_1/ip/clk_wiz_0" \
"C:/AMDDesignTools/2025.2/Vivado/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \

vcom -work xpm  -93  \
"C:/AMDDesignTools/2025.2/Vivado/data/ip/xpm/xpm_VCOMP.vhd" \

vlog -work xil_defaultlib  -incr -mfcu  "+incdir+../../../../../../AMDDesignTools/2025.2/Vivado/data/rsb/busdef" "+incdir+../../../Rolling Average Filter DSP.gen/sources_1/ip/clk_wiz_0" \
"../../../Rolling Average Filter DSP.gen/sources_1/ip/clk_wiz_0/clk_wiz_0_clk_wiz.v" \
"../../../Rolling Average Filter DSP.gen/sources_1/ip/clk_wiz_0/clk_wiz_0.v" \

vlog -work xil_defaultlib  -incr -mfcu  -sv "+incdir+../../../../../../AMDDesignTools/2025.2/Vivado/data/rsb/busdef" "+incdir+../../../Rolling Average Filter DSP.gen/sources_1/ip/clk_wiz_0" \
"../../../Rolling Average Filter DSP.srcs/sources_1/new/rollingAverageFilter.sv" \
"../../../Rolling Average Filter DSP.srcs/sources_1/new/ADC1173_controller.sv" \
"../../../Rolling Average Filter DSP.srcs/sources_1/new/DAC7311_controller.sv" \
"../../../Rolling Average Filter DSP.srcs/sources_1/new/Top_lvl.sv" \
"../../../Rolling Average Filter DSP.srcs/sim_1/new/rollingAverageFilter_tb.sv" \
"../../../Rolling Average Filter DSP.srcs/sim_1/new/DAC7311_controller_tb.sv" \
"../../../Rolling Average Filter DSP.srcs/sim_1/new/ADC1173_Controller_tb.sv" \
"../../../Rolling Average Filter DSP.srcs/sim_1/new/Top_lvl_tb.sv" \

vlog -work xil_defaultlib \
"glbl.v"


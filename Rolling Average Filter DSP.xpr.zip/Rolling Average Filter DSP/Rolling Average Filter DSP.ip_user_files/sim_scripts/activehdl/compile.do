transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

vlib work
vlib activehdl/xpm
vlib activehdl/xil_defaultlib

vmap xpm activehdl/xpm
vmap xil_defaultlib activehdl/xil_defaultlib

vlog -work xpm  -sv2k12 "+incdir+../../../../../../AMDDesignTools/2025.2/Vivado/data/rsb/busdef" "+incdir+../../../Rolling Average Filter DSP.gen/sources_1/ip/clk_wiz_0" -l xpm -l xil_defaultlib \
"C:/AMDDesignTools/2025.2/Vivado/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \

vcom -work xpm -93  \
"C:/AMDDesignTools/2025.2/Vivado/data/ip/xpm/xpm_VCOMP.vhd" \

vlog -work xil_defaultlib  -v2k5 "+incdir+../../../../../../AMDDesignTools/2025.2/Vivado/data/rsb/busdef" "+incdir+../../../Rolling Average Filter DSP.gen/sources_1/ip/clk_wiz_0" -l xpm -l xil_defaultlib \
"../../../Rolling Average Filter DSP.gen/sources_1/ip/clk_wiz_0/clk_wiz_0_clk_wiz.v" \
"../../../Rolling Average Filter DSP.gen/sources_1/ip/clk_wiz_0/clk_wiz_0.v" \

vlog -work xil_defaultlib  -sv2k12 "+incdir+../../../../../../AMDDesignTools/2025.2/Vivado/data/rsb/busdef" "+incdir+../../../Rolling Average Filter DSP.gen/sources_1/ip/clk_wiz_0" -l xpm -l xil_defaultlib \
"../../../Rolling Average Filter DSP.srcs/sources_1/new/rollingAverageFilter.sv" \
"../../../Rolling Average Filter DSP.srcs/sources_1/new/ADC1173_controller.sv" \
"../../../Rolling Average Filter DSP.srcs/sources_1/new/DAC7311_controller.sv" \
"../../../Rolling Average Filter DSP.srcs/sources_1/new/Top_lvl.sv" \
"../../../Rolling Average Filter DSP.srcs/sim_1/new/rollingAverageFilter_tb.sv" \
"../../../Rolling Average Filter DSP.srcs/sim_1/new/DAC7311_controller_tb.sv" \
"../../../Rolling Average Filter DSP.srcs/sim_1/new/ADC1173_Controller_tb.sv" \
"../../../Rolling Average Filter DSP.srcs/sim_1/new/Top_lvl_tb.sv" \

vlog -work xil_defaultlib \
"glbl.v"


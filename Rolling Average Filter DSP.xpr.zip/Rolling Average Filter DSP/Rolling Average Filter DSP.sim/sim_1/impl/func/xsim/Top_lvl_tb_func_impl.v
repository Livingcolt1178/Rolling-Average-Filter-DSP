// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Wed Apr  8 17:22:22 2026
// Host        : NicksGLaptop running 64-bit major release  (build 9200)
// Command     : write_verilog -mode funcsim -nolib -force -file {C:/Users/nrbra/Rolling Average Filter DSP/Rolling
//               Average Filter DSP.sim/sim_1/impl/func/xsim/Top_lvl_tb_func_impl.v}
// Design      : top_lvl
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7s15ftgb196-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module ADC1173_Controller
   (SR,
    E,
    ADC_en_n_OBUF,
    Q,
    rst_n_IBUF,
    locked,
    clk_out1,
    D);
  output [0:0]SR;
  output [0:0]E;
  output ADC_en_n_OBUF;
  output [7:0]Q;
  input rst_n_IBUF;
  input locked;
  input clk_out1;
  input [7:0]D;

  wire \ADC_Dout[0]_i_2_n_0 ;
  wire \ADC_Dout[0]_i_3_n_0 ;
  wire \ADC_Dout[1]_i_2_n_0 ;
  wire \ADC_Dout[1]_i_3_n_0 ;
  wire \ADC_Dout[2]_i_2_n_0 ;
  wire \ADC_Dout[2]_i_3_n_0 ;
  wire \ADC_Dout[3]_i_2_n_0 ;
  wire \ADC_Dout[3]_i_3_n_0 ;
  wire \ADC_Dout[4]_i_2_n_0 ;
  wire \ADC_Dout[4]_i_3_n_0 ;
  wire \ADC_Dout[5]_i_2_n_0 ;
  wire \ADC_Dout[5]_i_3_n_0 ;
  wire \ADC_Dout[6]_i_2_n_0 ;
  wire \ADC_Dout[6]_i_3_n_0 ;
  wire \ADC_Dout[7]_i_2_n_0 ;
  wire \ADC_Dout[7]_i_3_n_0 ;
  wire ADC_en_n_OBUF;
  wire [7:0]D;
  wire [0:0]E;
  wire [7:0]Q;
  wire [0:0]SR;
  wire clk_out1;
  wire [3:0]count;
  wire \count[1]_i_1_n_0 ;
  wire \count[3]_i_1_n_0 ;
  wire [3:0]count_reg;
  wire [7:0]fifo;
  wire \fifo[0][7]_i_1_n_0 ;
  wire \fifo[1][7]_i_1_n_0 ;
  wire \fifo[2][7]_i_1_n_0 ;
  wire \fifo[3][7]_i_1_n_0 ;
  wire \fifo[4][7]_i_1_n_0 ;
  wire \fifo[5][7]_i_1_n_0 ;
  wire \fifo[6][7]_i_1_n_0 ;
  wire \fifo[7][7]_i_1_n_0 ;
  wire [7:0]\fifo_reg[0] ;
  wire [7:0]\fifo_reg[1] ;
  wire [7:0]\fifo_reg[2] ;
  wire [7:0]\fifo_reg[3] ;
  wire [7:0]\fifo_reg[4] ;
  wire [7:0]\fifo_reg[5] ;
  wire [7:0]\fifo_reg[6] ;
  wire [7:0]\fifo_reg[7] ;
  wire locked;
  wire [2:0]raddr;
  wire \raddr[0]_i_1_n_0 ;
  wire \raddr[1]_i_1_n_0 ;
  wire \raddr[2]_i_1_n_0 ;
  wire rst_n_IBUF;
  wire sample_strobe;
  wire [3:0]strob_counter;
  wire \strob_counter[0]_i_1_n_0 ;
  wire \strob_counter[1]_i_1_n_0 ;
  wire \strob_counter[2]_i_1_n_0 ;
  wire \strob_counter[3]_i_1_n_0 ;
  wire [2:0]waddr;
  wire \waddr[0]_i_1_n_0 ;
  wire \waddr[1]_i_1_n_0 ;
  wire \waddr[2]_i_1_n_0 ;
  wire \waddr[2]_i_2_n_0 ;

  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ADC_Dout[0]_i_2 
       (.I0(\fifo_reg[3] [0]),
        .I1(\fifo_reg[2] [0]),
        .I2(raddr[1]),
        .I3(\fifo_reg[1] [0]),
        .I4(raddr[0]),
        .I5(\fifo_reg[0] [0]),
        .O(\ADC_Dout[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ADC_Dout[0]_i_3 
       (.I0(\fifo_reg[7] [0]),
        .I1(\fifo_reg[6] [0]),
        .I2(raddr[1]),
        .I3(\fifo_reg[5] [0]),
        .I4(raddr[0]),
        .I5(\fifo_reg[4] [0]),
        .O(\ADC_Dout[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ADC_Dout[1]_i_2 
       (.I0(\fifo_reg[3] [1]),
        .I1(\fifo_reg[2] [1]),
        .I2(raddr[1]),
        .I3(\fifo_reg[1] [1]),
        .I4(raddr[0]),
        .I5(\fifo_reg[0] [1]),
        .O(\ADC_Dout[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ADC_Dout[1]_i_3 
       (.I0(\fifo_reg[7] [1]),
        .I1(\fifo_reg[6] [1]),
        .I2(raddr[1]),
        .I3(\fifo_reg[5] [1]),
        .I4(raddr[0]),
        .I5(\fifo_reg[4] [1]),
        .O(\ADC_Dout[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ADC_Dout[2]_i_2 
       (.I0(\fifo_reg[3] [2]),
        .I1(\fifo_reg[2] [2]),
        .I2(raddr[1]),
        .I3(\fifo_reg[1] [2]),
        .I4(raddr[0]),
        .I5(\fifo_reg[0] [2]),
        .O(\ADC_Dout[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ADC_Dout[2]_i_3 
       (.I0(\fifo_reg[7] [2]),
        .I1(\fifo_reg[6] [2]),
        .I2(raddr[1]),
        .I3(\fifo_reg[5] [2]),
        .I4(raddr[0]),
        .I5(\fifo_reg[4] [2]),
        .O(\ADC_Dout[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ADC_Dout[3]_i_2 
       (.I0(\fifo_reg[3] [3]),
        .I1(\fifo_reg[2] [3]),
        .I2(raddr[1]),
        .I3(\fifo_reg[1] [3]),
        .I4(raddr[0]),
        .I5(\fifo_reg[0] [3]),
        .O(\ADC_Dout[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ADC_Dout[3]_i_3 
       (.I0(\fifo_reg[7] [3]),
        .I1(\fifo_reg[6] [3]),
        .I2(raddr[1]),
        .I3(\fifo_reg[5] [3]),
        .I4(raddr[0]),
        .I5(\fifo_reg[4] [3]),
        .O(\ADC_Dout[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ADC_Dout[4]_i_2 
       (.I0(\fifo_reg[3] [4]),
        .I1(\fifo_reg[2] [4]),
        .I2(raddr[1]),
        .I3(\fifo_reg[1] [4]),
        .I4(raddr[0]),
        .I5(\fifo_reg[0] [4]),
        .O(\ADC_Dout[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ADC_Dout[4]_i_3 
       (.I0(\fifo_reg[7] [4]),
        .I1(\fifo_reg[6] [4]),
        .I2(raddr[1]),
        .I3(\fifo_reg[5] [4]),
        .I4(raddr[0]),
        .I5(\fifo_reg[4] [4]),
        .O(\ADC_Dout[4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ADC_Dout[5]_i_2 
       (.I0(\fifo_reg[3] [5]),
        .I1(\fifo_reg[2] [5]),
        .I2(raddr[1]),
        .I3(\fifo_reg[1] [5]),
        .I4(raddr[0]),
        .I5(\fifo_reg[0] [5]),
        .O(\ADC_Dout[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ADC_Dout[5]_i_3 
       (.I0(\fifo_reg[7] [5]),
        .I1(\fifo_reg[6] [5]),
        .I2(raddr[1]),
        .I3(\fifo_reg[5] [5]),
        .I4(raddr[0]),
        .I5(\fifo_reg[4] [5]),
        .O(\ADC_Dout[5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ADC_Dout[6]_i_2 
       (.I0(\fifo_reg[3] [6]),
        .I1(\fifo_reg[2] [6]),
        .I2(raddr[1]),
        .I3(\fifo_reg[1] [6]),
        .I4(raddr[0]),
        .I5(\fifo_reg[0] [6]),
        .O(\ADC_Dout[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ADC_Dout[6]_i_3 
       (.I0(\fifo_reg[7] [6]),
        .I1(\fifo_reg[6] [6]),
        .I2(raddr[1]),
        .I3(\fifo_reg[5] [6]),
        .I4(raddr[0]),
        .I5(\fifo_reg[4] [6]),
        .O(\ADC_Dout[6]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ADC_Dout[7]_i_2 
       (.I0(\fifo_reg[3] [7]),
        .I1(\fifo_reg[2] [7]),
        .I2(raddr[1]),
        .I3(\fifo_reg[1] [7]),
        .I4(raddr[0]),
        .I5(\fifo_reg[0] [7]),
        .O(\ADC_Dout[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ADC_Dout[7]_i_3 
       (.I0(\fifo_reg[7] [7]),
        .I1(\fifo_reg[6] [7]),
        .I2(raddr[1]),
        .I3(\fifo_reg[5] [7]),
        .I4(raddr[0]),
        .I5(\fifo_reg[4] [7]),
        .O(\ADC_Dout[7]_i_3_n_0 ));
  FDCE #(
    .INIT(1'b0)) 
    \ADC_Dout_reg[0] 
       (.C(clk_out1),
        .CE(E),
        .CLR(SR),
        .D(fifo[0]),
        .Q(Q[0]));
  MUXF7 \ADC_Dout_reg[0]_i_1 
       (.I0(\ADC_Dout[0]_i_2_n_0 ),
        .I1(\ADC_Dout[0]_i_3_n_0 ),
        .O(fifo[0]),
        .S(raddr[2]));
  FDCE #(
    .INIT(1'b0)) 
    \ADC_Dout_reg[1] 
       (.C(clk_out1),
        .CE(E),
        .CLR(SR),
        .D(fifo[1]),
        .Q(Q[1]));
  MUXF7 \ADC_Dout_reg[1]_i_1 
       (.I0(\ADC_Dout[1]_i_2_n_0 ),
        .I1(\ADC_Dout[1]_i_3_n_0 ),
        .O(fifo[1]),
        .S(raddr[2]));
  FDCE #(
    .INIT(1'b0)) 
    \ADC_Dout_reg[2] 
       (.C(clk_out1),
        .CE(E),
        .CLR(SR),
        .D(fifo[2]),
        .Q(Q[2]));
  MUXF7 \ADC_Dout_reg[2]_i_1 
       (.I0(\ADC_Dout[2]_i_2_n_0 ),
        .I1(\ADC_Dout[2]_i_3_n_0 ),
        .O(fifo[2]),
        .S(raddr[2]));
  FDCE #(
    .INIT(1'b0)) 
    \ADC_Dout_reg[3] 
       (.C(clk_out1),
        .CE(E),
        .CLR(SR),
        .D(fifo[3]),
        .Q(Q[3]));
  MUXF7 \ADC_Dout_reg[3]_i_1 
       (.I0(\ADC_Dout[3]_i_2_n_0 ),
        .I1(\ADC_Dout[3]_i_3_n_0 ),
        .O(fifo[3]),
        .S(raddr[2]));
  FDCE #(
    .INIT(1'b0)) 
    \ADC_Dout_reg[4] 
       (.C(clk_out1),
        .CE(E),
        .CLR(SR),
        .D(fifo[4]),
        .Q(Q[4]));
  MUXF7 \ADC_Dout_reg[4]_i_1 
       (.I0(\ADC_Dout[4]_i_2_n_0 ),
        .I1(\ADC_Dout[4]_i_3_n_0 ),
        .O(fifo[4]),
        .S(raddr[2]));
  FDCE #(
    .INIT(1'b0)) 
    \ADC_Dout_reg[5] 
       (.C(clk_out1),
        .CE(E),
        .CLR(SR),
        .D(fifo[5]),
        .Q(Q[5]));
  MUXF7 \ADC_Dout_reg[5]_i_1 
       (.I0(\ADC_Dout[5]_i_2_n_0 ),
        .I1(\ADC_Dout[5]_i_3_n_0 ),
        .O(fifo[5]),
        .S(raddr[2]));
  FDCE #(
    .INIT(1'b0)) 
    \ADC_Dout_reg[6] 
       (.C(clk_out1),
        .CE(E),
        .CLR(SR),
        .D(fifo[6]),
        .Q(Q[6]));
  MUXF7 \ADC_Dout_reg[6]_i_1 
       (.I0(\ADC_Dout[6]_i_2_n_0 ),
        .I1(\ADC_Dout[6]_i_3_n_0 ),
        .O(fifo[6]),
        .S(raddr[2]));
  FDCE #(
    .INIT(1'b0)) 
    \ADC_Dout_reg[7] 
       (.C(clk_out1),
        .CE(E),
        .CLR(SR),
        .D(fifo[7]),
        .Q(Q[7]));
  MUXF7 \ADC_Dout_reg[7]_i_1 
       (.I0(\ADC_Dout[7]_i_2_n_0 ),
        .I1(\ADC_Dout[7]_i_3_n_0 ),
        .O(fifo[7]),
        .S(raddr[2]));
  (* \PinAttr:I3:HOLD_DETOUR  = "186" *) 
  LUT4 #(
    .INIT(16'h0010)) 
    ADC_en_n_OBUF_inst_i_1
       (.I0(count_reg[2]),
        .I1(count_reg[1]),
        .I2(count_reg[3]),
        .I3(count_reg[0]),
        .O(ADC_en_n_OBUF));
  (* \PinAttr:I0:HOLD_DETOUR  = "186" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \count[0]_i_1 
       (.I0(count_reg[0]),
        .O(count[0]));
  (* \PinAttr:I3:HOLD_DETOUR  = "194" *) 
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hF00E)) 
    \count[1]_i_1 
       (.I0(count_reg[2]),
        .I1(count_reg[3]),
        .I2(count_reg[1]),
        .I3(count_reg[0]),
        .O(\count[1]_i_1_n_0 ));
  (* \PinAttr:I1:HOLD_DETOUR  = "194" *) 
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hF0C2)) 
    \count[2]_i_1 
       (.I0(count_reg[3]),
        .I1(count_reg[0]),
        .I2(count_reg[2]),
        .I3(count_reg[1]),
        .O(count[2]));
  LUT5 #(
    .INIT(32'h55555556)) 
    \count[3]_i_1 
       (.I0(\waddr[2]_i_2_n_0 ),
        .I1(count_reg[0]),
        .I2(count_reg[1]),
        .I3(count_reg[3]),
        .I4(count_reg[2]),
        .O(\count[3]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'hF0E0)) 
    \count[3]_i_2 
       (.I0(count_reg[0]),
        .I1(count_reg[1]),
        .I2(count_reg[3]),
        .I3(count_reg[2]),
        .O(count[3]));
  FDCE #(
    .INIT(1'b0)) 
    \count_reg[0] 
       (.C(clk_out1),
        .CE(\count[3]_i_1_n_0 ),
        .CLR(SR),
        .D(count[0]),
        .Q(count_reg[0]));
  FDCE #(
    .INIT(1'b0)) 
    \count_reg[1] 
       (.C(clk_out1),
        .CE(\count[3]_i_1_n_0 ),
        .CLR(SR),
        .D(\count[1]_i_1_n_0 ),
        .Q(count_reg[1]));
  FDCE #(
    .INIT(1'b0)) 
    \count_reg[2] 
       (.C(clk_out1),
        .CE(\count[3]_i_1_n_0 ),
        .CLR(SR),
        .D(count[2]),
        .Q(count_reg[2]));
  FDCE #(
    .INIT(1'b0)) 
    \count_reg[3] 
       (.C(clk_out1),
        .CE(\count[3]_i_1_n_0 ),
        .CLR(SR),
        .D(count[3]),
        .Q(count_reg[3]));
  LUT4 #(
    .INIT(16'h0002)) 
    \fifo[0][7]_i_1 
       (.I0(\waddr[2]_i_2_n_0 ),
        .I1(waddr[1]),
        .I2(waddr[0]),
        .I3(waddr[2]),
        .O(\fifo[0][7]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0020)) 
    \fifo[1][7]_i_1 
       (.I0(\waddr[2]_i_2_n_0 ),
        .I1(waddr[1]),
        .I2(waddr[0]),
        .I3(waddr[2]),
        .O(\fifo[1][7]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0020)) 
    \fifo[2][7]_i_1 
       (.I0(\waddr[2]_i_2_n_0 ),
        .I1(waddr[2]),
        .I2(waddr[1]),
        .I3(waddr[0]),
        .O(\fifo[2][7]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h2000)) 
    \fifo[3][7]_i_1 
       (.I0(\waddr[2]_i_2_n_0 ),
        .I1(waddr[2]),
        .I2(waddr[0]),
        .I3(waddr[1]),
        .O(\fifo[3][7]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0020)) 
    \fifo[4][7]_i_1 
       (.I0(\waddr[2]_i_2_n_0 ),
        .I1(waddr[1]),
        .I2(waddr[2]),
        .I3(waddr[0]),
        .O(\fifo[4][7]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h2000)) 
    \fifo[5][7]_i_1 
       (.I0(\waddr[2]_i_2_n_0 ),
        .I1(waddr[1]),
        .I2(waddr[0]),
        .I3(waddr[2]),
        .O(\fifo[5][7]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h2000)) 
    \fifo[6][7]_i_1 
       (.I0(\waddr[2]_i_2_n_0 ),
        .I1(waddr[0]),
        .I2(waddr[2]),
        .I3(waddr[1]),
        .O(\fifo[6][7]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h8000)) 
    \fifo[7][7]_i_1 
       (.I0(\waddr[2]_i_2_n_0 ),
        .I1(waddr[0]),
        .I2(waddr[2]),
        .I3(waddr[1]),
        .O(\fifo[7][7]_i_1_n_0 ));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[0][0] 
       (.C(clk_out1),
        .CE(\fifo[0][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[0]),
        .Q(\fifo_reg[0] [0]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[0][1] 
       (.C(clk_out1),
        .CE(\fifo[0][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[1]),
        .Q(\fifo_reg[0] [1]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[0][2] 
       (.C(clk_out1),
        .CE(\fifo[0][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[2]),
        .Q(\fifo_reg[0] [2]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[0][3] 
       (.C(clk_out1),
        .CE(\fifo[0][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[3]),
        .Q(\fifo_reg[0] [3]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[0][4] 
       (.C(clk_out1),
        .CE(\fifo[0][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[4]),
        .Q(\fifo_reg[0] [4]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[0][5] 
       (.C(clk_out1),
        .CE(\fifo[0][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[5]),
        .Q(\fifo_reg[0] [5]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[0][6] 
       (.C(clk_out1),
        .CE(\fifo[0][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[6]),
        .Q(\fifo_reg[0] [6]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[0][7] 
       (.C(clk_out1),
        .CE(\fifo[0][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[7]),
        .Q(\fifo_reg[0] [7]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[1][0] 
       (.C(clk_out1),
        .CE(\fifo[1][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[0]),
        .Q(\fifo_reg[1] [0]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[1][1] 
       (.C(clk_out1),
        .CE(\fifo[1][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[1]),
        .Q(\fifo_reg[1] [1]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[1][2] 
       (.C(clk_out1),
        .CE(\fifo[1][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[2]),
        .Q(\fifo_reg[1] [2]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[1][3] 
       (.C(clk_out1),
        .CE(\fifo[1][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[3]),
        .Q(\fifo_reg[1] [3]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[1][4] 
       (.C(clk_out1),
        .CE(\fifo[1][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[4]),
        .Q(\fifo_reg[1] [4]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[1][5] 
       (.C(clk_out1),
        .CE(\fifo[1][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[5]),
        .Q(\fifo_reg[1] [5]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[1][6] 
       (.C(clk_out1),
        .CE(\fifo[1][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[6]),
        .Q(\fifo_reg[1] [6]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[1][7] 
       (.C(clk_out1),
        .CE(\fifo[1][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[7]),
        .Q(\fifo_reg[1] [7]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[2][0] 
       (.C(clk_out1),
        .CE(\fifo[2][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[0]),
        .Q(\fifo_reg[2] [0]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[2][1] 
       (.C(clk_out1),
        .CE(\fifo[2][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[1]),
        .Q(\fifo_reg[2] [1]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[2][2] 
       (.C(clk_out1),
        .CE(\fifo[2][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[2]),
        .Q(\fifo_reg[2] [2]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[2][3] 
       (.C(clk_out1),
        .CE(\fifo[2][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[3]),
        .Q(\fifo_reg[2] [3]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[2][4] 
       (.C(clk_out1),
        .CE(\fifo[2][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[4]),
        .Q(\fifo_reg[2] [4]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[2][5] 
       (.C(clk_out1),
        .CE(\fifo[2][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[5]),
        .Q(\fifo_reg[2] [5]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[2][6] 
       (.C(clk_out1),
        .CE(\fifo[2][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[6]),
        .Q(\fifo_reg[2] [6]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[2][7] 
       (.C(clk_out1),
        .CE(\fifo[2][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[7]),
        .Q(\fifo_reg[2] [7]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[3][0] 
       (.C(clk_out1),
        .CE(\fifo[3][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[0]),
        .Q(\fifo_reg[3] [0]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[3][1] 
       (.C(clk_out1),
        .CE(\fifo[3][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[1]),
        .Q(\fifo_reg[3] [1]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[3][2] 
       (.C(clk_out1),
        .CE(\fifo[3][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[2]),
        .Q(\fifo_reg[3] [2]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[3][3] 
       (.C(clk_out1),
        .CE(\fifo[3][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[3]),
        .Q(\fifo_reg[3] [3]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[3][4] 
       (.C(clk_out1),
        .CE(\fifo[3][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[4]),
        .Q(\fifo_reg[3] [4]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[3][5] 
       (.C(clk_out1),
        .CE(\fifo[3][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[5]),
        .Q(\fifo_reg[3] [5]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[3][6] 
       (.C(clk_out1),
        .CE(\fifo[3][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[6]),
        .Q(\fifo_reg[3] [6]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[3][7] 
       (.C(clk_out1),
        .CE(\fifo[3][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[7]),
        .Q(\fifo_reg[3] [7]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[4][0] 
       (.C(clk_out1),
        .CE(\fifo[4][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[0]),
        .Q(\fifo_reg[4] [0]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[4][1] 
       (.C(clk_out1),
        .CE(\fifo[4][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[1]),
        .Q(\fifo_reg[4] [1]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[4][2] 
       (.C(clk_out1),
        .CE(\fifo[4][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[2]),
        .Q(\fifo_reg[4] [2]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[4][3] 
       (.C(clk_out1),
        .CE(\fifo[4][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[3]),
        .Q(\fifo_reg[4] [3]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[4][4] 
       (.C(clk_out1),
        .CE(\fifo[4][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[4]),
        .Q(\fifo_reg[4] [4]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[4][5] 
       (.C(clk_out1),
        .CE(\fifo[4][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[5]),
        .Q(\fifo_reg[4] [5]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[4][6] 
       (.C(clk_out1),
        .CE(\fifo[4][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[6]),
        .Q(\fifo_reg[4] [6]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[4][7] 
       (.C(clk_out1),
        .CE(\fifo[4][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[7]),
        .Q(\fifo_reg[4] [7]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[5][0] 
       (.C(clk_out1),
        .CE(\fifo[5][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[0]),
        .Q(\fifo_reg[5] [0]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[5][1] 
       (.C(clk_out1),
        .CE(\fifo[5][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[1]),
        .Q(\fifo_reg[5] [1]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[5][2] 
       (.C(clk_out1),
        .CE(\fifo[5][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[2]),
        .Q(\fifo_reg[5] [2]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[5][3] 
       (.C(clk_out1),
        .CE(\fifo[5][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[3]),
        .Q(\fifo_reg[5] [3]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[5][4] 
       (.C(clk_out1),
        .CE(\fifo[5][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[4]),
        .Q(\fifo_reg[5] [4]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[5][5] 
       (.C(clk_out1),
        .CE(\fifo[5][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[5]),
        .Q(\fifo_reg[5] [5]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[5][6] 
       (.C(clk_out1),
        .CE(\fifo[5][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[6]),
        .Q(\fifo_reg[5] [6]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[5][7] 
       (.C(clk_out1),
        .CE(\fifo[5][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[7]),
        .Q(\fifo_reg[5] [7]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[6][0] 
       (.C(clk_out1),
        .CE(\fifo[6][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[0]),
        .Q(\fifo_reg[6] [0]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[6][1] 
       (.C(clk_out1),
        .CE(\fifo[6][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[1]),
        .Q(\fifo_reg[6] [1]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[6][2] 
       (.C(clk_out1),
        .CE(\fifo[6][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[2]),
        .Q(\fifo_reg[6] [2]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[6][3] 
       (.C(clk_out1),
        .CE(\fifo[6][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[3]),
        .Q(\fifo_reg[6] [3]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[6][4] 
       (.C(clk_out1),
        .CE(\fifo[6][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[4]),
        .Q(\fifo_reg[6] [4]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[6][5] 
       (.C(clk_out1),
        .CE(\fifo[6][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[5]),
        .Q(\fifo_reg[6] [5]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[6][6] 
       (.C(clk_out1),
        .CE(\fifo[6][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[6]),
        .Q(\fifo_reg[6] [6]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[6][7] 
       (.C(clk_out1),
        .CE(\fifo[6][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[7]),
        .Q(\fifo_reg[6] [7]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[7][0] 
       (.C(clk_out1),
        .CE(\fifo[7][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[0]),
        .Q(\fifo_reg[7] [0]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[7][1] 
       (.C(clk_out1),
        .CE(\fifo[7][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[1]),
        .Q(\fifo_reg[7] [1]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[7][2] 
       (.C(clk_out1),
        .CE(\fifo[7][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[2]),
        .Q(\fifo_reg[7] [2]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[7][3] 
       (.C(clk_out1),
        .CE(\fifo[7][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[3]),
        .Q(\fifo_reg[7] [3]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[7][4] 
       (.C(clk_out1),
        .CE(\fifo[7][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[4]),
        .Q(\fifo_reg[7] [4]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[7][5] 
       (.C(clk_out1),
        .CE(\fifo[7][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[5]),
        .Q(\fifo_reg[7] [5]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[7][6] 
       (.C(clk_out1),
        .CE(\fifo[7][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[6]),
        .Q(\fifo_reg[7] [6]));
  FDCE #(
    .INIT(1'b0)) 
    \fifo_reg[7][7] 
       (.C(clk_out1),
        .CE(\fifo[7][7]_i_1_n_0 ),
        .CLR(SR),
        .D(D[7]),
        .Q(\fifo_reg[7] [7]));
  LUT4 #(
    .INIT(16'hFFFE)) 
    led_green_OBUF_inst_i_1
       (.I0(count_reg[0]),
        .I1(count_reg[1]),
        .I2(count_reg[3]),
        .I3(count_reg[2]),
        .O(E));
  LUT1 #(
    .INIT(2'h1)) 
    \raddr[0]_i_1 
       (.I0(raddr[0]),
        .O(\raddr[0]_i_1_n_0 ));
  (* \PinAttr:I1:HOLD_DETOUR  = "193" *) 
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \raddr[1]_i_1 
       (.I0(raddr[0]),
        .I1(raddr[1]),
        .O(\raddr[1]_i_1_n_0 ));
  (* \PinAttr:I1:HOLD_DETOUR  = "193" *) 
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \raddr[2]_i_1 
       (.I0(raddr[0]),
        .I1(raddr[1]),
        .I2(raddr[2]),
        .O(\raddr[2]_i_1_n_0 ));
  FDCE #(
    .INIT(1'b0)) 
    \raddr_reg[0] 
       (.C(clk_out1),
        .CE(E),
        .CLR(SR),
        .D(\raddr[0]_i_1_n_0 ),
        .Q(raddr[0]));
  FDCE #(
    .INIT(1'b0)) 
    \raddr_reg[1] 
       (.C(clk_out1),
        .CE(E),
        .CLR(SR),
        .D(\raddr[1]_i_1_n_0 ),
        .Q(raddr[1]));
  FDCE #(
    .INIT(1'b0)) 
    \raddr_reg[2] 
       (.C(clk_out1),
        .CE(E),
        .CLR(SR),
        .D(\raddr[2]_i_1_n_0 ),
        .Q(raddr[2]));
  LUT1 #(
    .INIT(2'h1)) 
    \strob_counter[0]_i_1 
       (.I0(strob_counter[0]),
        .O(\strob_counter[0]_i_1_n_0 ));
  (* \PinAttr:I0:HOLD_DETOUR  = "196" *) 
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \strob_counter[1]_i_1 
       (.I0(strob_counter[1]),
        .I1(strob_counter[0]),
        .O(\strob_counter[1]_i_1_n_0 ));
  (* \PinAttr:I0:HOLD_DETOUR  = "196" *) 
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \strob_counter[2]_i_1 
       (.I0(strob_counter[1]),
        .I1(strob_counter[0]),
        .I2(strob_counter[2]),
        .O(\strob_counter[2]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h7F80)) 
    \strob_counter[3]_i_1 
       (.I0(strob_counter[1]),
        .I1(strob_counter[0]),
        .I2(strob_counter[2]),
        .I3(strob_counter[3]),
        .O(\strob_counter[3]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \strob_counter[3]_i_2 
       (.I0(rst_n_IBUF),
        .I1(locked),
        .O(SR));
  FDCE #(
    .INIT(1'b0)) 
    \strob_counter_reg[0] 
       (.C(clk_out1),
        .CE(1'b1),
        .CLR(SR),
        .D(\strob_counter[0]_i_1_n_0 ),
        .Q(strob_counter[0]));
  FDCE #(
    .INIT(1'b0)) 
    \strob_counter_reg[1] 
       (.C(clk_out1),
        .CE(1'b1),
        .CLR(SR),
        .D(\strob_counter[1]_i_1_n_0 ),
        .Q(strob_counter[1]));
  FDCE #(
    .INIT(1'b0)) 
    \strob_counter_reg[2] 
       (.C(clk_out1),
        .CE(1'b1),
        .CLR(SR),
        .D(\strob_counter[2]_i_1_n_0 ),
        .Q(strob_counter[2]));
  FDCE #(
    .INIT(1'b0)) 
    \strob_counter_reg[3] 
       (.C(clk_out1),
        .CE(1'b1),
        .CLR(SR),
        .D(\strob_counter[3]_i_1_n_0 ),
        .Q(strob_counter[3]));
  LUT2 #(
    .INIT(4'h6)) 
    \waddr[0]_i_1 
       (.I0(\waddr[2]_i_2_n_0 ),
        .I1(waddr[0]),
        .O(\waddr[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \waddr[1]_i_1 
       (.I0(waddr[0]),
        .I1(\waddr[2]_i_2_n_0 ),
        .I2(waddr[1]),
        .O(\waddr[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \waddr[2]_i_1 
       (.I0(waddr[1]),
        .I1(waddr[0]),
        .I2(\waddr[2]_i_2_n_0 ),
        .I3(waddr[2]),
        .O(\waddr[2]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hAAAAAA8A)) 
    \waddr[2]_i_2 
       (.I0(sample_strobe),
        .I1(count_reg[0]),
        .I2(count_reg[3]),
        .I3(count_reg[1]),
        .I4(count_reg[2]),
        .O(\waddr[2]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h8000)) 
    \waddr[2]_i_3 
       (.I0(strob_counter[3]),
        .I1(strob_counter[2]),
        .I2(strob_counter[0]),
        .I3(strob_counter[1]),
        .O(sample_strobe));
  FDCE #(
    .INIT(1'b0)) 
    \waddr_reg[0] 
       (.C(clk_out1),
        .CE(1'b1),
        .CLR(SR),
        .D(\waddr[0]_i_1_n_0 ),
        .Q(waddr[0]));
  FDCE #(
    .INIT(1'b0)) 
    \waddr_reg[1] 
       (.C(clk_out1),
        .CE(1'b1),
        .CLR(SR),
        .D(\waddr[1]_i_1_n_0 ),
        .Q(waddr[1]));
  FDCE #(
    .INIT(1'b0)) 
    \waddr_reg[2] 
       (.C(clk_out1),
        .CE(1'b1),
        .CLR(SR),
        .D(\waddr[2]_i_1_n_0 ),
        .Q(waddr[2]));
endmodule

module DAC7311_Controller
   (DAC_sync_n_OBUF,
    DAC_Dout_OBUF,
    p_0_in,
    led_red_OBUF,
    internal_rst_n,
    \data_reg_reg[12]_0 ,
    \data_reg_reg[11]_0 ,
    \data_reg_reg[10]_0 ,
    \data_reg_reg[9]_0 ,
    \data_reg_reg[8]_0 ,
    \data_reg_reg[7]_0 ,
    \data_reg_reg[6]_0 ,
    \data_reg_reg[5]_0 ,
    SR,
    clk_out1,
    DAC_start,
    data_valid,
    locked,
    rst_n_IBUF,
    \data_reg_reg[13]_0 ,
    \data_reg_reg[12]_1 ,
    \data_reg_reg[11]_1 ,
    \data_reg_reg[10]_1 ,
    \data_reg_reg[9]_1 ,
    \data_reg_reg[8]_1 ,
    \data_reg_reg[7]_1 ,
    \data_reg_reg[6]_1 );
  output DAC_sync_n_OBUF;
  output DAC_Dout_OBUF;
  output p_0_in;
  output led_red_OBUF;
  output internal_rst_n;
  output \data_reg_reg[12]_0 ;
  output \data_reg_reg[11]_0 ;
  output \data_reg_reg[10]_0 ;
  output \data_reg_reg[9]_0 ;
  output \data_reg_reg[8]_0 ;
  output \data_reg_reg[7]_0 ;
  output \data_reg_reg[6]_0 ;
  output \data_reg_reg[5]_0 ;
  input [0:0]SR;
  input clk_out1;
  input DAC_start;
  input data_valid;
  input locked;
  input rst_n_IBUF;
  input \data_reg_reg[13]_0 ;
  input \data_reg_reg[12]_1 ;
  input \data_reg_reg[11]_1 ;
  input \data_reg_reg[10]_1 ;
  input \data_reg_reg[9]_1 ;
  input \data_reg_reg[8]_1 ;
  input \data_reg_reg[7]_1 ;
  input \data_reg_reg[6]_1 ;

  wire DAC_Dout_OBUF;
  wire DAC_Dout_i_1_n_0;
  wire DAC_ready_inv_i_1_n_0;
  wire DAC_start;
  wire DAC_sync_n_OBUF;
  wire DAC_sync_n_i_1_n_0;
  wire DAC_sync_n_i_2_n_0;
  wire [0:0]SR;
  wire \bit_cnt[0]_i_1_n_0 ;
  wire \bit_cnt[1]_i_1_n_0 ;
  wire \bit_cnt[2]_i_1_n_0 ;
  wire \bit_cnt[3]_i_1_n_0 ;
  wire \bit_cnt_reg_n_0_[0] ;
  wire \bit_cnt_reg_n_0_[1] ;
  wire \bit_cnt_reg_n_0_[2] ;
  wire \bit_cnt_reg_n_0_[3] ;
  wire clk_out1;
  wire \data_reg[14]_i_1_n_0 ;
  wire \data_reg[14]_i_2_n_0 ;
  wire \data_reg[14]_i_3_n_0 ;
  wire \data_reg[1]_i_1_n_0 ;
  wire \data_reg[2]_i_1_n_0 ;
  wire \data_reg[3]_i_1_n_0 ;
  wire \data_reg[4]_i_1_n_0 ;
  wire \data_reg[5]_i_1_n_0 ;
  wire \data_reg_reg[10]_0 ;
  wire \data_reg_reg[10]_1 ;
  wire \data_reg_reg[11]_0 ;
  wire \data_reg_reg[11]_1 ;
  wire \data_reg_reg[12]_0 ;
  wire \data_reg_reg[12]_1 ;
  wire \data_reg_reg[13]_0 ;
  wire \data_reg_reg[5]_0 ;
  wire \data_reg_reg[6]_0 ;
  wire \data_reg_reg[6]_1 ;
  wire \data_reg_reg[7]_0 ;
  wire \data_reg_reg[7]_1 ;
  wire \data_reg_reg[8]_0 ;
  wire \data_reg_reg[8]_1 ;
  wire \data_reg_reg[9]_0 ;
  wire \data_reg_reg[9]_1 ;
  wire \data_reg_reg_n_0_[0] ;
  wire \data_reg_reg_n_0_[13] ;
  wire \data_reg_reg_n_0_[1] ;
  wire \data_reg_reg_n_0_[2] ;
  wire \data_reg_reg_n_0_[3] ;
  wire \data_reg_reg_n_0_[4] ;
  wire data_valid;
  wire internal_rst_n;
  wire led_red_OBUF;
  wire locked;
  wire p_0_in;
  wire p_2_in;
  wire rst_n_IBUF;

  LUT4 #(
    .INIT(16'h4FFF)) 
    DAC_Dout_i_1
       (.I0(p_0_in),
        .I1(data_valid),
        .I2(rst_n_IBUF),
        .I3(locked),
        .O(DAC_Dout_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    DAC_Dout_reg
       (.C(clk_out1),
        .CE(p_0_in),
        .D(p_2_in),
        .Q(DAC_Dout_OBUF),
        .R(DAC_Dout_i_1_n_0));
  LUT6 #(
    .INIT(64'h7FFFFFFF7FFF0000)) 
    DAC_ready_inv_i_1
       (.I0(\bit_cnt_reg_n_0_[1] ),
        .I1(\bit_cnt_reg_n_0_[0] ),
        .I2(\bit_cnt_reg_n_0_[2] ),
        .I3(\bit_cnt_reg_n_0_[3] ),
        .I4(p_0_in),
        .I5(data_valid),
        .O(DAC_ready_inv_i_1_n_0));
  (* inverted = "yes" *) 
  FDRE #(
    .INIT(1'b0)) 
    DAC_ready_reg_inv
       (.C(clk_out1),
        .CE(1'b1),
        .D(DAC_ready_inv_i_1_n_0),
        .Q(p_0_in),
        .R(SR));
  LUT5 #(
    .INIT(32'h8000FFFF)) 
    DAC_sync_n_i_1
       (.I0(\bit_cnt_reg_n_0_[1] ),
        .I1(\bit_cnt_reg_n_0_[0] ),
        .I2(\bit_cnt_reg_n_0_[2] ),
        .I3(\bit_cnt_reg_n_0_[3] ),
        .I4(p_0_in),
        .O(DAC_sync_n_i_1_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    DAC_sync_n_i_2
       (.I0(p_0_in),
        .I1(data_valid),
        .O(DAC_sync_n_i_2_n_0));
  FDSE #(
    .INIT(1'b1)) 
    DAC_sync_n_reg
       (.C(clk_out1),
        .CE(DAC_sync_n_i_1_n_0),
        .D(DAC_sync_n_i_2_n_0),
        .Q(DAC_sync_n_OBUF),
        .S(SR));
  LUT3 #(
    .INIT(8'h3E)) 
    \bit_cnt[0]_i_1 
       (.I0(data_valid),
        .I1(p_0_in),
        .I2(\bit_cnt_reg_n_0_[0] ),
        .O(\bit_cnt[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h600060000000A000)) 
    \bit_cnt[1]_i_1 
       (.I0(\bit_cnt_reg_n_0_[1] ),
        .I1(\bit_cnt_reg_n_0_[0] ),
        .I2(locked),
        .I3(rst_n_IBUF),
        .I4(data_valid),
        .I5(p_0_in),
        .O(\bit_cnt[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h6A006A000000AA00)) 
    \bit_cnt[2]_i_1 
       (.I0(\bit_cnt_reg_n_0_[2] ),
        .I1(\bit_cnt_reg_n_0_[0] ),
        .I2(\bit_cnt_reg_n_0_[1] ),
        .I3(internal_rst_n),
        .I4(data_valid),
        .I5(p_0_in),
        .O(\bit_cnt[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h000000006AAAAAAA)) 
    \bit_cnt[3]_i_1 
       (.I0(\bit_cnt_reg_n_0_[3] ),
        .I1(p_0_in),
        .I2(\bit_cnt_reg_n_0_[2] ),
        .I3(\bit_cnt_reg_n_0_[1] ),
        .I4(\bit_cnt_reg_n_0_[0] ),
        .I5(DAC_Dout_i_1_n_0),
        .O(\bit_cnt[3]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \bit_cnt_reg[0] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\bit_cnt[0]_i_1_n_0 ),
        .Q(\bit_cnt_reg_n_0_[0] ),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \bit_cnt_reg[1] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\bit_cnt[1]_i_1_n_0 ),
        .Q(\bit_cnt_reg_n_0_[1] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \bit_cnt_reg[2] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\bit_cnt[2]_i_1_n_0 ),
        .Q(\bit_cnt_reg_n_0_[2] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \bit_cnt_reg[3] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\bit_cnt[3]_i_1_n_0 ),
        .Q(\bit_cnt_reg_n_0_[3] ),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h7)) 
    \data_reg[14]_i_1 
       (.I0(rst_n_IBUF),
        .I1(locked),
        .O(\data_reg[14]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \data_reg[14]_i_2 
       (.I0(p_0_in),
        .I1(data_valid),
        .O(\data_reg[14]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    \data_reg[14]_i_3 
       (.I0(\data_reg_reg_n_0_[13] ),
        .I1(p_0_in),
        .I2(data_valid),
        .O(\data_reg[14]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hF4)) 
    \data_reg[1]_i_1 
       (.I0(p_0_in),
        .I1(data_valid),
        .I2(\data_reg_reg_n_0_[0] ),
        .O(\data_reg[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    \data_reg[2]_i_1 
       (.I0(\data_reg_reg_n_0_[1] ),
        .I1(p_0_in),
        .I2(data_valid),
        .O(\data_reg[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    \data_reg[3]_i_1 
       (.I0(\data_reg_reg_n_0_[2] ),
        .I1(p_0_in),
        .I2(data_valid),
        .O(\data_reg[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    \data_reg[4]_i_1 
       (.I0(\data_reg_reg_n_0_[3] ),
        .I1(p_0_in),
        .I2(data_valid),
        .O(\data_reg[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    \data_reg[5]_i_1 
       (.I0(\data_reg_reg_n_0_[4] ),
        .I1(p_0_in),
        .I2(data_valid),
        .O(\data_reg[5]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg_reg[0] 
       (.C(clk_out1),
        .CE(\data_reg[14]_i_2_n_0 ),
        .D(DAC_start),
        .Q(\data_reg_reg_n_0_[0] ),
        .R(\data_reg[14]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg_reg[10] 
       (.C(clk_out1),
        .CE(\data_reg[14]_i_2_n_0 ),
        .D(\data_reg_reg[10]_1 ),
        .Q(\data_reg_reg[10]_0 ),
        .R(\data_reg[14]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg_reg[11] 
       (.C(clk_out1),
        .CE(\data_reg[14]_i_2_n_0 ),
        .D(\data_reg_reg[11]_1 ),
        .Q(\data_reg_reg[11]_0 ),
        .R(\data_reg[14]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg_reg[12] 
       (.C(clk_out1),
        .CE(\data_reg[14]_i_2_n_0 ),
        .D(\data_reg_reg[12]_1 ),
        .Q(\data_reg_reg[12]_0 ),
        .R(\data_reg[14]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg_reg[13] 
       (.C(clk_out1),
        .CE(\data_reg[14]_i_2_n_0 ),
        .D(\data_reg_reg[13]_0 ),
        .Q(\data_reg_reg_n_0_[13] ),
        .R(\data_reg[14]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg_reg[14] 
       (.C(clk_out1),
        .CE(\data_reg[14]_i_2_n_0 ),
        .D(\data_reg[14]_i_3_n_0 ),
        .Q(p_2_in),
        .R(\data_reg[14]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg_reg[1] 
       (.C(clk_out1),
        .CE(\data_reg[14]_i_2_n_0 ),
        .D(\data_reg[1]_i_1_n_0 ),
        .Q(\data_reg_reg_n_0_[1] ),
        .R(\data_reg[14]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg_reg[2] 
       (.C(clk_out1),
        .CE(\data_reg[14]_i_2_n_0 ),
        .D(\data_reg[2]_i_1_n_0 ),
        .Q(\data_reg_reg_n_0_[2] ),
        .R(\data_reg[14]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg_reg[3] 
       (.C(clk_out1),
        .CE(\data_reg[14]_i_2_n_0 ),
        .D(\data_reg[3]_i_1_n_0 ),
        .Q(\data_reg_reg_n_0_[3] ),
        .R(\data_reg[14]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg_reg[4] 
       (.C(clk_out1),
        .CE(\data_reg[14]_i_2_n_0 ),
        .D(\data_reg[4]_i_1_n_0 ),
        .Q(\data_reg_reg_n_0_[4] ),
        .R(\data_reg[14]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg_reg[5] 
       (.C(clk_out1),
        .CE(\data_reg[14]_i_2_n_0 ),
        .D(\data_reg[5]_i_1_n_0 ),
        .Q(\data_reg_reg[5]_0 ),
        .R(\data_reg[14]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg_reg[6] 
       (.C(clk_out1),
        .CE(\data_reg[14]_i_2_n_0 ),
        .D(\data_reg_reg[6]_1 ),
        .Q(\data_reg_reg[6]_0 ),
        .R(\data_reg[14]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg_reg[7] 
       (.C(clk_out1),
        .CE(\data_reg[14]_i_2_n_0 ),
        .D(\data_reg_reg[7]_1 ),
        .Q(\data_reg_reg[7]_0 ),
        .R(\data_reg[14]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg_reg[8] 
       (.C(clk_out1),
        .CE(\data_reg[14]_i_2_n_0 ),
        .D(\data_reg_reg[8]_1 ),
        .Q(\data_reg_reg[8]_0 ),
        .R(\data_reg[14]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg_reg[9] 
       (.C(clk_out1),
        .CE(\data_reg[14]_i_2_n_0 ),
        .D(\data_reg_reg[9]_1 ),
        .Q(\data_reg_reg[9]_0 ),
        .R(\data_reg[14]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    data_valid_i_1
       (.I0(locked),
        .I1(rst_n_IBUF),
        .O(internal_rst_n));
  FDRE #(
    .INIT(1'b0)) 
    led_red_reg
       (.C(clk_out1),
        .CE(DAC_sync_n_i_1_n_0),
        .D(DAC_start),
        .Q(led_red_OBUF),
        .R(SR));
endmodule

module clk_wiz_0
   (clk_out1,
    resetn,
    locked,
    sys_clk);
  output clk_out1;
  input resetn;
  output locked;
  input sys_clk;

  wire clk_out1;
  wire locked;
  wire sys_clk;
  wire NLW_inst_resetn_UNCONNECTED;

  clk_wiz_0_clk_wiz inst
       (.clk_out1(clk_out1),
        .locked(locked),
        .resetn(NLW_inst_resetn_UNCONNECTED),
        .sys_clk(sys_clk));
endmodule

module clk_wiz_0_clk_wiz
   (clk_out1,
    resetn,
    locked,
    sys_clk);
  output clk_out1;
  input resetn;
  output locked;
  input sys_clk;

  wire clk_out1;
  wire clk_out1_clk_wiz_0;
  wire clkfbout_clk_wiz_0;
  wire locked;
  wire sys_clk;
  wire sys_clk_clk_wiz_0;
  wire NLW_plle2_adv_inst_CLKOUT1_UNCONNECTED;
  wire NLW_plle2_adv_inst_CLKOUT2_UNCONNECTED;
  wire NLW_plle2_adv_inst_CLKOUT3_UNCONNECTED;
  wire NLW_plle2_adv_inst_CLKOUT4_UNCONNECTED;
  wire NLW_plle2_adv_inst_CLKOUT5_UNCONNECTED;
  wire NLW_plle2_adv_inst_DRDY_UNCONNECTED;
  wire [15:0]NLW_plle2_adv_inst_DO_UNCONNECTED;

  (* BOX_TYPE = "PRIMITIVE" *) 
  (* CAPACITANCE = "DONT_CARE" *) 
  (* IBUF_DELAY_VALUE = "0" *) 
  (* IFD_DELAY_VALUE = "AUTO" *) 
  IBUF #(
    .IOSTANDARD("DEFAULT")) 
    clkin1_ibufg
       (.I(sys_clk),
        .O(sys_clk_clk_wiz_0));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG clkout1_buf
       (.I(clk_out1_clk_wiz_0),
        .O(clk_out1));
  (* BOX_TYPE = "PRIMITIVE" *) 
  PLLE2_ADV #(
    .BANDWIDTH("OPTIMIZED"),
    .CLKFBOUT_MULT(17),
    .CLKFBOUT_PHASE(0.000000),
    .CLKIN1_PERIOD(10.000000),
    .CLKIN2_PERIOD(0.000000),
    .CLKOUT0_DIVIDE(17),
    .CLKOUT0_DUTY_CYCLE(0.500000),
    .CLKOUT0_PHASE(0.000000),
    .CLKOUT1_DIVIDE(1),
    .CLKOUT1_DUTY_CYCLE(0.500000),
    .CLKOUT1_PHASE(0.000000),
    .CLKOUT2_DIVIDE(1),
    .CLKOUT2_DUTY_CYCLE(0.500000),
    .CLKOUT2_PHASE(0.000000),
    .CLKOUT3_DIVIDE(1),
    .CLKOUT3_DUTY_CYCLE(0.500000),
    .CLKOUT3_PHASE(0.000000),
    .CLKOUT4_DIVIDE(1),
    .CLKOUT4_DUTY_CYCLE(0.500000),
    .CLKOUT4_PHASE(0.000000),
    .CLKOUT5_DIVIDE(1),
    .CLKOUT5_DUTY_CYCLE(0.500000),
    .CLKOUT5_PHASE(0.000000),
    .COMPENSATION("INTERNAL"),
    .DIVCLK_DIVIDE(2),
    .IS_CLKINSEL_INVERTED(1'b0),
    .IS_PWRDWN_INVERTED(1'b0),
    .IS_RST_INVERTED(1'b0),
    .REF_JITTER1(0.010000),
    .REF_JITTER2(0.010000),
    .STARTUP_WAIT("FALSE")) 
    plle2_adv_inst
       (.CLKFBIN(clkfbout_clk_wiz_0),
        .CLKFBOUT(clkfbout_clk_wiz_0),
        .CLKIN1(sys_clk_clk_wiz_0),
        .CLKIN2(1'b0),
        .CLKINSEL(1'b1),
        .CLKOUT0(clk_out1_clk_wiz_0),
        .CLKOUT1(NLW_plle2_adv_inst_CLKOUT1_UNCONNECTED),
        .CLKOUT2(NLW_plle2_adv_inst_CLKOUT2_UNCONNECTED),
        .CLKOUT3(NLW_plle2_adv_inst_CLKOUT3_UNCONNECTED),
        .CLKOUT4(NLW_plle2_adv_inst_CLKOUT4_UNCONNECTED),
        .CLKOUT5(NLW_plle2_adv_inst_CLKOUT5_UNCONNECTED),
        .DADDR({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .DCLK(1'b0),
        .DEN(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .DO(NLW_plle2_adv_inst_DO_UNCONNECTED[15:0]),
        .DRDY(NLW_plle2_adv_inst_DRDY_UNCONNECTED),
        .DWE(1'b0),
        .LOCKED(locked),
        .PWRDWN(1'b0),
        .RST(1'b0));
endmodule

module rollingAverageFilter
   (data_valid,
    \filter_Dout_reg[11]_0 ,
    \filter_Dout_reg[10]_0 ,
    \filter_Dout_reg[9]_0 ,
    \filter_Dout_reg[8]_0 ,
    \filter_Dout_reg[7]_0 ,
    \filter_Dout_reg[6]_0 ,
    \filter_Dout_reg[5]_0 ,
    \filter_Dout_reg[4]_0 ,
    DAC_start,
    internal_rst_n,
    clk_out1,
    p_0_in,
    \data_reg_reg[13] ,
    \data_reg_reg[12] ,
    \data_reg_reg[11] ,
    \data_reg_reg[10] ,
    \data_reg_reg[9] ,
    \data_reg_reg[8] ,
    \data_reg_reg[7] ,
    \data_reg_reg[6] ,
    SR,
    D);
  output data_valid;
  output \filter_Dout_reg[11]_0 ;
  output \filter_Dout_reg[10]_0 ;
  output \filter_Dout_reg[9]_0 ;
  output \filter_Dout_reg[8]_0 ;
  output \filter_Dout_reg[7]_0 ;
  output \filter_Dout_reg[6]_0 ;
  output \filter_Dout_reg[5]_0 ;
  output \filter_Dout_reg[4]_0 ;
  output DAC_start;
  input internal_rst_n;
  input clk_out1;
  input p_0_in;
  input \data_reg_reg[13] ;
  input \data_reg_reg[12] ;
  input \data_reg_reg[11] ;
  input \data_reg_reg[10] ;
  input \data_reg_reg[9] ;
  input \data_reg_reg[8] ;
  input \data_reg_reg[7] ;
  input \data_reg_reg[6] ;
  input [0:0]SR;
  input [7:0]D;

  wire [7:0]D;
  wire DAC_start;
  wire [0:0]SR;
  wire clk_out1;
  wire \data_reg_reg[10] ;
  wire \data_reg_reg[11] ;
  wire \data_reg_reg[12] ;
  wire \data_reg_reg[13] ;
  wire \data_reg_reg[6] ;
  wire \data_reg_reg[7] ;
  wire \data_reg_reg[8] ;
  wire \data_reg_reg[9] ;
  wire data_valid;
  wire [11:4]filter_Dout;
  wire \filter_Dout_reg[10]_0 ;
  wire \filter_Dout_reg[11]_0 ;
  wire \filter_Dout_reg[4]_0 ;
  wire \filter_Dout_reg[5]_0 ;
  wire \filter_Dout_reg[6]_0 ;
  wire \filter_Dout_reg[7]_0 ;
  wire \filter_Dout_reg[8]_0 ;
  wire \filter_Dout_reg[9]_0 ;
  wire internal_rst_n;
  wire p_0_in;
  wire [7:0]\samples_reg[0] ;
  wire [7:0]\samples_reg[1] ;
  wire [7:0]\samples_reg[2] ;
  wire [7:0]\samples_reg[3] ;
  wire [9:2]sum0;
  wire sum0__2_carry__0_i_10_n_0;
  wire sum0__2_carry__0_i_11_n_0;
  wire sum0__2_carry__0_i_12_n_0;
  wire sum0__2_carry__0_i_1_n_0;
  wire sum0__2_carry__0_i_2_n_0;
  wire sum0__2_carry__0_i_3_n_0;
  wire sum0__2_carry__0_i_4_n_0;
  wire sum0__2_carry__0_i_5_n_0;
  wire sum0__2_carry__0_i_6_n_0;
  wire sum0__2_carry__0_i_7_n_0;
  wire sum0__2_carry__0_i_8_n_0;
  wire sum0__2_carry__0_i_9_n_0;
  wire sum0__2_carry__0_n_0;
  wire sum0__2_carry__1_i_1_n_0;
  wire sum0__2_carry__1_i_2_n_0;
  wire sum0__2_carry__1_i_3_n_0;
  wire sum0__2_carry_i_1_n_0;
  wire sum0__2_carry_i_2_n_0;
  wire sum0__2_carry_i_3_n_0;
  wire sum0__2_carry_i_4_n_0;
  wire sum0__2_carry_i_5_n_0;
  wire sum0__2_carry_i_6_n_0;
  wire sum0__2_carry_i_7_n_0;
  wire sum0__2_carry_i_8_n_0;
  wire sum0__2_carry_i_9_n_0;
  wire sum0__2_carry_n_0;
  wire [2:0]NLW_sum0__2_carry_CO_UNCONNECTED;
  wire [1:0]NLW_sum0__2_carry_O_UNCONNECTED;
  wire [2:0]NLW_sum0__2_carry__0_CO_UNCONNECTED;
  wire [3:0]NLW_sum0__2_carry__1_CO_UNCONNECTED;
  wire [3:1]NLW_sum0__2_carry__1_O_UNCONNECTED;

  LUT2 #(
    .INIT(4'h2)) 
    \data_reg[0]_i_1 
       (.I0(data_valid),
        .I1(p_0_in),
        .O(DAC_start));
  LUT4 #(
    .INIT(16'hFB08)) 
    \data_reg[10]_i_1 
       (.I0(filter_Dout[8]),
        .I1(data_valid),
        .I2(p_0_in),
        .I3(\data_reg_reg[10] ),
        .O(\filter_Dout_reg[8]_0 ));
  LUT4 #(
    .INIT(16'hFB08)) 
    \data_reg[11]_i_1 
       (.I0(filter_Dout[9]),
        .I1(data_valid),
        .I2(p_0_in),
        .I3(\data_reg_reg[11] ),
        .O(\filter_Dout_reg[9]_0 ));
  LUT4 #(
    .INIT(16'hFB08)) 
    \data_reg[12]_i_1 
       (.I0(filter_Dout[10]),
        .I1(data_valid),
        .I2(p_0_in),
        .I3(\data_reg_reg[12] ),
        .O(\filter_Dout_reg[10]_0 ));
  LUT4 #(
    .INIT(16'hFB08)) 
    \data_reg[13]_i_1 
       (.I0(filter_Dout[11]),
        .I1(data_valid),
        .I2(p_0_in),
        .I3(\data_reg_reg[13] ),
        .O(\filter_Dout_reg[11]_0 ));
  LUT4 #(
    .INIT(16'hFB08)) 
    \data_reg[6]_i_1 
       (.I0(filter_Dout[4]),
        .I1(data_valid),
        .I2(p_0_in),
        .I3(\data_reg_reg[6] ),
        .O(\filter_Dout_reg[4]_0 ));
  LUT4 #(
    .INIT(16'hFB08)) 
    \data_reg[7]_i_1 
       (.I0(filter_Dout[5]),
        .I1(data_valid),
        .I2(p_0_in),
        .I3(\data_reg_reg[7] ),
        .O(\filter_Dout_reg[5]_0 ));
  LUT4 #(
    .INIT(16'hFB08)) 
    \data_reg[8]_i_1 
       (.I0(filter_Dout[6]),
        .I1(data_valid),
        .I2(p_0_in),
        .I3(\data_reg_reg[8] ),
        .O(\filter_Dout_reg[6]_0 ));
  LUT4 #(
    .INIT(16'hFB08)) 
    \data_reg[9]_i_1 
       (.I0(filter_Dout[7]),
        .I1(data_valid),
        .I2(p_0_in),
        .I3(\data_reg_reg[9] ),
        .O(\filter_Dout_reg[7]_0 ));
  FDRE #(
    .INIT(1'b0)) 
    data_valid_reg
       (.C(clk_out1),
        .CE(1'b1),
        .D(internal_rst_n),
        .Q(data_valid),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \filter_Dout_reg[10] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(sum0[8]),
        .Q(filter_Dout[10]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \filter_Dout_reg[11] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(sum0[9]),
        .Q(filter_Dout[11]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \filter_Dout_reg[4] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(sum0[2]),
        .Q(filter_Dout[4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \filter_Dout_reg[5] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(sum0[3]),
        .Q(filter_Dout[5]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \filter_Dout_reg[6] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(sum0[4]),
        .Q(filter_Dout[6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \filter_Dout_reg[7] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(sum0[5]),
        .Q(filter_Dout[7]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \filter_Dout_reg[8] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(sum0[6]),
        .Q(filter_Dout[8]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \filter_Dout_reg[9] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(sum0[7]),
        .Q(filter_Dout[9]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[0][0] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(D[0]),
        .Q(\samples_reg[0] [0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[0][1] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(D[1]),
        .Q(\samples_reg[0] [1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[0][2] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(D[2]),
        .Q(\samples_reg[0] [2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[0][3] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(D[3]),
        .Q(\samples_reg[0] [3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[0][4] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(D[4]),
        .Q(\samples_reg[0] [4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[0][5] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(D[5]),
        .Q(\samples_reg[0] [5]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[0][6] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(D[6]),
        .Q(\samples_reg[0] [6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[0][7] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(D[7]),
        .Q(\samples_reg[0] [7]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[1][0] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[0] [0]),
        .Q(\samples_reg[1] [0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[1][1] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[0] [1]),
        .Q(\samples_reg[1] [1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[1][2] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[0] [2]),
        .Q(\samples_reg[1] [2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[1][3] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[0] [3]),
        .Q(\samples_reg[1] [3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[1][4] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[0] [4]),
        .Q(\samples_reg[1] [4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[1][5] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[0] [5]),
        .Q(\samples_reg[1] [5]),
        .R(SR));
  (* \PinAttr:D:HOLD_DETOUR  = "151" *) 
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[1][6] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[0] [6]),
        .Q(\samples_reg[1] [6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[1][7] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[0] [7]),
        .Q(\samples_reg[1] [7]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[2][0] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[1] [0]),
        .Q(\samples_reg[2] [0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[2][1] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[1] [1]),
        .Q(\samples_reg[2] [1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[2][2] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[1] [2]),
        .Q(\samples_reg[2] [2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[2][3] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[1] [3]),
        .Q(\samples_reg[2] [3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[2][4] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[1] [4]),
        .Q(\samples_reg[2] [4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[2][5] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[1] [5]),
        .Q(\samples_reg[2] [5]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[2][6] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[1] [6]),
        .Q(\samples_reg[2] [6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[2][7] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[1] [7]),
        .Q(\samples_reg[2] [7]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[3][0] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[2] [0]),
        .Q(\samples_reg[3] [0]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[3][1] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[2] [1]),
        .Q(\samples_reg[3] [1]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[3][2] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[2] [2]),
        .Q(\samples_reg[3] [2]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[3][3] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[2] [3]),
        .Q(\samples_reg[3] [3]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[3][4] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[2] [4]),
        .Q(\samples_reg[3] [4]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[3][5] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[2] [5]),
        .Q(\samples_reg[3] [5]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[3][6] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[2] [6]),
        .Q(\samples_reg[3] [6]),
        .R(SR));
  FDRE #(
    .INIT(1'b0)) 
    \samples_reg[3][7] 
       (.C(clk_out1),
        .CE(1'b1),
        .D(\samples_reg[2] [7]),
        .Q(\samples_reg[3] [7]),
        .R(SR));
  CARRY4 sum0__2_carry
       (.CI(1'b0),
        .CO({sum0__2_carry_n_0,NLW_sum0__2_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({sum0__2_carry_i_1_n_0,sum0__2_carry_i_2_n_0,sum0__2_carry_i_3_n_0,\samples_reg[0] [0]}),
        .O({sum0[3:2],NLW_sum0__2_carry_O_UNCONNECTED[1:0]}),
        .S({sum0__2_carry_i_4_n_0,sum0__2_carry_i_5_n_0,sum0__2_carry_i_6_n_0,sum0__2_carry_i_7_n_0}));
  CARRY4 sum0__2_carry__0
       (.CI(sum0__2_carry_n_0),
        .CO({sum0__2_carry__0_n_0,NLW_sum0__2_carry__0_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({sum0__2_carry__0_i_1_n_0,sum0__2_carry__0_i_2_n_0,sum0__2_carry__0_i_3_n_0,sum0__2_carry__0_i_4_n_0}),
        .O(sum0[7:4]),
        .S({sum0__2_carry__0_i_5_n_0,sum0__2_carry__0_i_6_n_0,sum0__2_carry__0_i_7_n_0,sum0__2_carry__0_i_8_n_0}));
  LUT5 #(
    .INIT(32'hEEE8E888)) 
    sum0__2_carry__0_i_1
       (.I0(\samples_reg[0] [6]),
        .I1(sum0__2_carry__0_i_9_n_0),
        .I2(\samples_reg[3] [5]),
        .I3(\samples_reg[2] [5]),
        .I4(\samples_reg[1] [5]),
        .O(sum0__2_carry__0_i_1_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum0__2_carry__0_i_10
       (.I0(\samples_reg[3] [5]),
        .I1(\samples_reg[1] [5]),
        .I2(\samples_reg[2] [5]),
        .O(sum0__2_carry__0_i_10_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum0__2_carry__0_i_11
       (.I0(\samples_reg[3] [4]),
        .I1(\samples_reg[1] [4]),
        .I2(\samples_reg[2] [4]),
        .O(sum0__2_carry__0_i_11_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum0__2_carry__0_i_12
       (.I0(\samples_reg[3] [7]),
        .I1(\samples_reg[1] [7]),
        .I2(\samples_reg[2] [7]),
        .O(sum0__2_carry__0_i_12_n_0));
  LUT5 #(
    .INIT(32'hEEE8E888)) 
    sum0__2_carry__0_i_2
       (.I0(\samples_reg[0] [5]),
        .I1(sum0__2_carry__0_i_10_n_0),
        .I2(\samples_reg[3] [4]),
        .I3(\samples_reg[2] [4]),
        .I4(\samples_reg[1] [4]),
        .O(sum0__2_carry__0_i_2_n_0));
  LUT5 #(
    .INIT(32'hEEE8E888)) 
    sum0__2_carry__0_i_3
       (.I0(\samples_reg[0] [4]),
        .I1(sum0__2_carry__0_i_11_n_0),
        .I2(\samples_reg[3] [3]),
        .I3(\samples_reg[2] [3]),
        .I4(\samples_reg[1] [3]),
        .O(sum0__2_carry__0_i_3_n_0));
  LUT5 #(
    .INIT(32'hEEE8E888)) 
    sum0__2_carry__0_i_4
       (.I0(\samples_reg[0] [3]),
        .I1(sum0__2_carry_i_9_n_0),
        .I2(\samples_reg[3] [2]),
        .I3(\samples_reg[2] [2]),
        .I4(\samples_reg[1] [2]),
        .O(sum0__2_carry__0_i_4_n_0));
  LUT6 #(
    .INIT(64'h6969699669969696)) 
    sum0__2_carry__0_i_5
       (.I0(sum0__2_carry__0_i_1_n_0),
        .I1(sum0__2_carry__0_i_12_n_0),
        .I2(\samples_reg[0] [7]),
        .I3(\samples_reg[1] [6]),
        .I4(\samples_reg[2] [6]),
        .I5(\samples_reg[3] [6]),
        .O(sum0__2_carry__0_i_5_n_0));
  LUT6 #(
    .INIT(64'h6969699669969696)) 
    sum0__2_carry__0_i_6
       (.I0(sum0__2_carry__0_i_2_n_0),
        .I1(sum0__2_carry__0_i_9_n_0),
        .I2(\samples_reg[0] [6]),
        .I3(\samples_reg[1] [5]),
        .I4(\samples_reg[2] [5]),
        .I5(\samples_reg[3] [5]),
        .O(sum0__2_carry__0_i_6_n_0));
  LUT6 #(
    .INIT(64'h6969699669969696)) 
    sum0__2_carry__0_i_7
       (.I0(sum0__2_carry__0_i_3_n_0),
        .I1(sum0__2_carry__0_i_10_n_0),
        .I2(\samples_reg[0] [5]),
        .I3(\samples_reg[1] [4]),
        .I4(\samples_reg[2] [4]),
        .I5(\samples_reg[3] [4]),
        .O(sum0__2_carry__0_i_7_n_0));
  LUT6 #(
    .INIT(64'h6969699669969696)) 
    sum0__2_carry__0_i_8
       (.I0(sum0__2_carry__0_i_4_n_0),
        .I1(sum0__2_carry__0_i_11_n_0),
        .I2(\samples_reg[0] [4]),
        .I3(\samples_reg[1] [3]),
        .I4(\samples_reg[2] [3]),
        .I5(\samples_reg[3] [3]),
        .O(sum0__2_carry__0_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum0__2_carry__0_i_9
       (.I0(\samples_reg[3] [6]),
        .I1(\samples_reg[1] [6]),
        .I2(\samples_reg[2] [6]),
        .O(sum0__2_carry__0_i_9_n_0));
  CARRY4 sum0__2_carry__1
       (.CI(sum0__2_carry__0_n_0),
        .CO({NLW_sum0__2_carry__1_CO_UNCONNECTED[3:2],sum0[9],NLW_sum0__2_carry__1_CO_UNCONNECTED[0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,sum0__2_carry__1_i_1_n_0}),
        .O({NLW_sum0__2_carry__1_O_UNCONNECTED[3:1],sum0[8]}),
        .S({1'b0,1'b0,1'b1,sum0__2_carry__1_i_2_n_0}));
  LUT5 #(
    .INIT(32'hEEE8E888)) 
    sum0__2_carry__1_i_1
       (.I0(\samples_reg[0] [7]),
        .I1(sum0__2_carry__0_i_12_n_0),
        .I2(\samples_reg[3] [6]),
        .I3(\samples_reg[2] [6]),
        .I4(\samples_reg[1] [6]),
        .O(sum0__2_carry__1_i_1_n_0));
  LUT5 #(
    .INIT(32'h177E7EE8)) 
    sum0__2_carry__1_i_2
       (.I0(sum0__2_carry__1_i_3_n_0),
        .I1(\samples_reg[0] [7]),
        .I2(\samples_reg[3] [7]),
        .I3(\samples_reg[2] [7]),
        .I4(\samples_reg[1] [7]),
        .O(sum0__2_carry__1_i_2_n_0));
  LUT3 #(
    .INIT(8'hE8)) 
    sum0__2_carry__1_i_3
       (.I0(\samples_reg[1] [6]),
        .I1(\samples_reg[2] [6]),
        .I2(\samples_reg[3] [6]),
        .O(sum0__2_carry__1_i_3_n_0));
  LUT5 #(
    .INIT(32'hEEE8E888)) 
    sum0__2_carry_i_1
       (.I0(\samples_reg[0] [2]),
        .I1(sum0__2_carry_i_8_n_0),
        .I2(\samples_reg[3] [1]),
        .I3(\samples_reg[2] [1]),
        .I4(\samples_reg[1] [1]),
        .O(sum0__2_carry_i_1_n_0));
  LUT5 #(
    .INIT(32'hE81717E8)) 
    sum0__2_carry_i_2
       (.I0(\samples_reg[3] [1]),
        .I1(\samples_reg[2] [1]),
        .I2(\samples_reg[1] [1]),
        .I3(\samples_reg[0] [2]),
        .I4(sum0__2_carry_i_8_n_0),
        .O(sum0__2_carry_i_2_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    sum0__2_carry_i_3
       (.I0(\samples_reg[2] [1]),
        .I1(\samples_reg[1] [1]),
        .I2(\samples_reg[3] [1]),
        .I3(\samples_reg[0] [1]),
        .O(sum0__2_carry_i_3_n_0));
  LUT6 #(
    .INIT(64'h6969699669969696)) 
    sum0__2_carry_i_4
       (.I0(sum0__2_carry_i_1_n_0),
        .I1(sum0__2_carry_i_9_n_0),
        .I2(\samples_reg[0] [3]),
        .I3(\samples_reg[1] [2]),
        .I4(\samples_reg[2] [2]),
        .I5(\samples_reg[3] [2]),
        .O(sum0__2_carry_i_4_n_0));
  LUT6 #(
    .INIT(64'h6999999699969666)) 
    sum0__2_carry_i_5
       (.I0(sum0__2_carry_i_8_n_0),
        .I1(\samples_reg[0] [2]),
        .I2(\samples_reg[3] [1]),
        .I3(\samples_reg[1] [1]),
        .I4(\samples_reg[2] [1]),
        .I5(\samples_reg[0] [1]),
        .O(sum0__2_carry_i_5_n_0));
  LUT4 #(
    .INIT(16'h566A)) 
    sum0__2_carry_i_6
       (.I0(sum0__2_carry_i_3_n_0),
        .I1(\samples_reg[3] [0]),
        .I2(\samples_reg[2] [0]),
        .I3(\samples_reg[1] [0]),
        .O(sum0__2_carry_i_6_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    sum0__2_carry_i_7
       (.I0(\samples_reg[2] [0]),
        .I1(\samples_reg[1] [0]),
        .I2(\samples_reg[3] [0]),
        .I3(\samples_reg[0] [0]),
        .O(sum0__2_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum0__2_carry_i_8
       (.I0(\samples_reg[3] [2]),
        .I1(\samples_reg[1] [2]),
        .I2(\samples_reg[2] [2]),
        .O(sum0__2_carry_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    sum0__2_carry_i_9
       (.I0(\samples_reg[3] [3]),
        .I1(\samples_reg[1] [3]),
        .I2(\samples_reg[2] [3]),
        .O(sum0__2_carry_i_9_n_0));
endmodule

(* ECO_CHECKSUM = "bf948697" *) 
(* NotValidForBitStream *)
(* \DesignAttr:ENABLE_NOC_NETLIST_VIEW  *) 
(* \DesignAttr:ENABLE_AIE_NETLIST_VIEW  *) 
module top_lvl
   (sys_clk,
    rst_n,
    ADC_Din,
    ADC_clk,
    ADC_en_n,
    DAC_Dout,
    DAC_sync_n,
    DAC_clk,
    led_green,
    led_red);
  input sys_clk;
  input rst_n;
  input [7:0]ADC_Din;
  output ADC_clk;
  output ADC_en_n;
  output DAC_Dout;
  output DAC_sync_n;
  output DAC_clk;
  output led_green;
  output led_red;

  wire [7:0]ADC_Din;
  wire [7:0]ADC_Din_IBUF;
  wire [7:0]ADC_Dout;
  wire ADC_clk;
  wire ADC_en_n;
  wire ADC_en_n_OBUF;
  wire DAC_Dout;
  wire DAC_Dout_OBUF;
  wire DAC_clk;
  wire DAC_clk_OBUF;
  wire DAC_start;
  wire DAC_sync_n;
  wire DAC_sync_n_OBUF;
  wire adc_ctrl_n_0;
  wire dac_ctrl_n_10;
  wire dac_ctrl_n_11;
  wire dac_ctrl_n_12;
  wire dac_ctrl_n_5;
  wire dac_ctrl_n_6;
  wire dac_ctrl_n_7;
  wire dac_ctrl_n_8;
  wire dac_ctrl_n_9;
  wire data_valid;
  wire filter_n_1;
  wire filter_n_2;
  wire filter_n_3;
  wire filter_n_4;
  wire filter_n_5;
  wire filter_n_6;
  wire filter_n_7;
  wire filter_n_8;
  wire internal_rst_n;
  wire led_green;
  wire led_green_OBUF;
  wire led_red;
  wire led_red_OBUF;
  wire locked;
  wire p_0_in;
  wire rst_n;
  wire rst_n_IBUF;
  (* IBUF_LOW_PWR *) wire sys_clk;
  wire NLW_u_clk_gen_resetn_UNCONNECTED;

  IBUF \ADC_Din_IBUF[0]_inst 
       (.I(ADC_Din[0]),
        .O(ADC_Din_IBUF[0]));
  IBUF \ADC_Din_IBUF[1]_inst 
       (.I(ADC_Din[1]),
        .O(ADC_Din_IBUF[1]));
  IBUF \ADC_Din_IBUF[2]_inst 
       (.I(ADC_Din[2]),
        .O(ADC_Din_IBUF[2]));
  IBUF \ADC_Din_IBUF[3]_inst 
       (.I(ADC_Din[3]),
        .O(ADC_Din_IBUF[3]));
  IBUF \ADC_Din_IBUF[4]_inst 
       (.I(ADC_Din[4]),
        .O(ADC_Din_IBUF[4]));
  IBUF \ADC_Din_IBUF[5]_inst 
       (.I(ADC_Din[5]),
        .O(ADC_Din_IBUF[5]));
  IBUF \ADC_Din_IBUF[6]_inst 
       (.I(ADC_Din[6]),
        .O(ADC_Din_IBUF[6]));
  IBUF \ADC_Din_IBUF[7]_inst 
       (.I(ADC_Din[7]),
        .O(ADC_Din_IBUF[7]));
  OBUF ADC_clk_OBUF_inst
       (.I(DAC_clk_OBUF),
        .O(ADC_clk));
  OBUF ADC_en_n_OBUF_inst
       (.I(ADC_en_n_OBUF),
        .O(ADC_en_n));
  OBUF DAC_Dout_OBUF_inst
       (.I(DAC_Dout_OBUF),
        .O(DAC_Dout));
  OBUF DAC_clk_OBUF_inst
       (.I(DAC_clk_OBUF),
        .O(DAC_clk));
  OBUF DAC_sync_n_OBUF_inst
       (.I(DAC_sync_n_OBUF),
        .O(DAC_sync_n));
  ADC1173_Controller adc_ctrl
       (.ADC_en_n_OBUF(ADC_en_n_OBUF),
        .D(ADC_Din_IBUF),
        .E(led_green_OBUF),
        .Q(ADC_Dout),
        .SR(adc_ctrl_n_0),
        .clk_out1(DAC_clk_OBUF),
        .locked(locked),
        .rst_n_IBUF(rst_n_IBUF));
  DAC7311_Controller dac_ctrl
       (.DAC_Dout_OBUF(DAC_Dout_OBUF),
        .DAC_start(DAC_start),
        .DAC_sync_n_OBUF(DAC_sync_n_OBUF),
        .SR(adc_ctrl_n_0),
        .clk_out1(DAC_clk_OBUF),
        .\data_reg_reg[10]_0 (dac_ctrl_n_7),
        .\data_reg_reg[10]_1 (filter_n_4),
        .\data_reg_reg[11]_0 (dac_ctrl_n_6),
        .\data_reg_reg[11]_1 (filter_n_3),
        .\data_reg_reg[12]_0 (dac_ctrl_n_5),
        .\data_reg_reg[12]_1 (filter_n_2),
        .\data_reg_reg[13]_0 (filter_n_1),
        .\data_reg_reg[5]_0 (dac_ctrl_n_12),
        .\data_reg_reg[6]_0 (dac_ctrl_n_11),
        .\data_reg_reg[6]_1 (filter_n_8),
        .\data_reg_reg[7]_0 (dac_ctrl_n_10),
        .\data_reg_reg[7]_1 (filter_n_7),
        .\data_reg_reg[8]_0 (dac_ctrl_n_9),
        .\data_reg_reg[8]_1 (filter_n_6),
        .\data_reg_reg[9]_0 (dac_ctrl_n_8),
        .\data_reg_reg[9]_1 (filter_n_5),
        .data_valid(data_valid),
        .internal_rst_n(internal_rst_n),
        .led_red_OBUF(led_red_OBUF),
        .locked(locked),
        .p_0_in(p_0_in),
        .rst_n_IBUF(rst_n_IBUF));
  rollingAverageFilter filter
       (.D(ADC_Dout),
        .DAC_start(DAC_start),
        .SR(adc_ctrl_n_0),
        .clk_out1(DAC_clk_OBUF),
        .\data_reg_reg[10] (dac_ctrl_n_8),
        .\data_reg_reg[11] (dac_ctrl_n_7),
        .\data_reg_reg[12] (dac_ctrl_n_6),
        .\data_reg_reg[13] (dac_ctrl_n_5),
        .\data_reg_reg[6] (dac_ctrl_n_12),
        .\data_reg_reg[7] (dac_ctrl_n_11),
        .\data_reg_reg[8] (dac_ctrl_n_10),
        .\data_reg_reg[9] (dac_ctrl_n_9),
        .data_valid(data_valid),
        .\filter_Dout_reg[10]_0 (filter_n_2),
        .\filter_Dout_reg[11]_0 (filter_n_1),
        .\filter_Dout_reg[4]_0 (filter_n_8),
        .\filter_Dout_reg[5]_0 (filter_n_7),
        .\filter_Dout_reg[6]_0 (filter_n_6),
        .\filter_Dout_reg[7]_0 (filter_n_5),
        .\filter_Dout_reg[8]_0 (filter_n_4),
        .\filter_Dout_reg[9]_0 (filter_n_3),
        .internal_rst_n(internal_rst_n),
        .p_0_in(p_0_in));
  OBUF led_green_OBUF_inst
       (.I(led_green_OBUF),
        .O(led_green));
  OBUF led_red_OBUF_inst
       (.I(led_red_OBUF),
        .O(led_red));
  IBUF rst_n_IBUF_inst
       (.I(rst_n),
        .O(rst_n_IBUF));
  (* IMPORTED_FROM = "c:/Users/nrbra/Rolling Average Filter DSP/Rolling Average Filter DSP.gen/sources_1/ip/clk_wiz_0/clk_wiz_0.dcp" *) 
  (* IMPORTED_TYPE = "CHECKPOINT" *) 
  (* IS_IMPORTED *) 
  clk_wiz_0 u_clk_gen
       (.clk_out1(DAC_clk_OBUF),
        .locked(locked),
        .resetn(NLW_u_clk_gen_resetn_UNCONNECTED),
        .sys_clk(sys_clk));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
